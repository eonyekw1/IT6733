CREATE DATABASE HR_Destination
GO
USE HR_Destination
CREATE TABLE employees (
    employee_id INT IDENTITY(1,1) PRIMARY KEY,
    first_name VARCHAR (20) DEFAULT NULL,
    last_name VARCHAR (25) NOT NULL,
    email VARCHAR (100) NOT NULL,
    phone_number VARCHAR (20) DEFAULT NULL,
    hire_date DATE NOT NULL,
    salary DECIMAL (8, 2) NOT NULL,
    job_title VARCHAR (35) NOT NULL,
	department_name VARCHAR (30) NOT NULL,
	state_province VARCHAR (25) DEFAULT NULL,
	country_name VARCHAR (40) DEFAULT NULL,
);
