CREATE VIEW vw_getEmployees
AS
SELECT employees.employee_id, first_name, last_name, email, phone_number, hire_date, salary, job_title, department_name, state_province, country_name
	FROM employees JOIN jobs ON employees.job_id = jobs.job_id
	JOIN departments ON departments.department_id = employees.department_id
	JOIN locations ON departments.location_id = locations.location_id 
	JOIN countries  ON locations.country_id = countries.country_id
